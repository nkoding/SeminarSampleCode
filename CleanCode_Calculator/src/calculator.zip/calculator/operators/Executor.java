package calculator.operators;

import java.util.Stack;

public interface Executor {

	public int execute(Stack<String> operands);
	
}
